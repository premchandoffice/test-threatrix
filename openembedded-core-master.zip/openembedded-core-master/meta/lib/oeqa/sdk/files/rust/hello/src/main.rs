fn main() {
    println!("Hello, OpenEmbedded world!");
}
